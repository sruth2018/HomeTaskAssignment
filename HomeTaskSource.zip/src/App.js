import logo from './logo.svg';
import './App.css';
import { Switch, Route } from 'react-router-dom'
import Main from './Components/Main'
import { Provider } from 'react-redux';
import store from './store';

function App() {
  return (
    <Provider store={store}>
      <div className="App">
        <Main />
      </div>
    </Provider>
  );
}

export default App;
