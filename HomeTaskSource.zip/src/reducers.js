import { UPDATE_USR } from './actions';

const initialState = {
    emailaddr: "",
    lastlogin: "",
};

function reducer(state = initialState, action) {
    switch (action.type) {

        case UPDATE_USR:
            return {
                emailaddr: action.emailaddr,
                lastlogin: action.lastlogin,
            };
        default:
            return state;
    }
}

export default reducer;