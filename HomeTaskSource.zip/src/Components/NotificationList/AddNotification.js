import React from 'react'
import './NotificationList.css';
import { IoNotificationsOutline, IoHomeOutline, IoLogOutOutline, IoAlertCircle } from 'react-icons/io5';
import { connect } from 'react-redux';
import { Link } from "react-router-dom";


class AddNotification extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            useremail: "",
            message: ""
        };

        this.usernamechangehandler = this.usernamechangehandler.bind(this);
        this.msgchangehandler = this.msgchangehandler.bind(this);
        this.addNotification = this.addNotification.bind(this);
    }

    usernamechangehandler(event) {
        this.setState({ useremail: event.target.value });
    }

    msgchangehandler(event) {
        this.setState({ message: event.target.value });
    }

    addNotification() {

        const timestamp = Date.now(); // This would be the timestamp you want to format
        let currentDateTime = new Intl.DateTimeFormat('en-US', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(timestamp);

        // POST request using fetch inside useEffect React hook
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                "date": currentDateTime,
                "message": this.state.message,
                "by": this.props.emailaddr,
                "to": this.state.useremail
            })
        };
        fetch('http://localhost:3001/notification', requestOptions)
            .then(async response => {

                const data = await response.json();

                // check for error response
                if (response.ok) {

                    alert("Notification registered succesfully.");
                } else {
                    alert("Unable to register notification. Please try again later!!!");
                }

            })
            .catch(error => {
                //this.setState({ errorMessage: error.toString() });
                console.error('There was an error!', error);
            });

    }

    render() {

        console.log(this.state.notificationList);

        return (

            <div className="container" style={{ display: 'flex' }}>
                <div style={{ flex: '0 0 25%', padding: '5px' }}>
                    <label htmlFor="uname"><b>Email address</b></label>
                    <input type="text" onChange={this.usernamechangehandler} placeholder="Enter email address" name="uname" required />
                </div>

                <div style={{ flex: '0 0 30%', padding: '5px' }}>
                    <label htmlFor="message"><b>Message</b></label>
                    {/* <input type="password" onChange={this.pswdchangehandler} placeholder="Enter Password" name="psw" required /> */}
                    <textarea onChange={this.msgchangehandler} name="message" rows="4" cols="50"></textarea>
                </div>
                <div style={{marginTop: '25px' }}>
                    <button type="submit" onClick={this.addNotification}>Add</button>
                </div>

            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        emailaddr: state.emailaddr,
        lastlogin: state.lastlogin
    };
}

export default connect(mapStateToProps)(AddNotification);