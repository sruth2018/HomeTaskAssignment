import React from 'react'
import './NotificationList.css';
import { IoNotificationsOutline, IoHomeOutline, IoLogOutOutline, IoAlertCircle } from 'react-icons/io5';
import { connect } from 'react-redux';
import { Link } from "react-router-dom";
import AddNotification from './AddNotification'

class NotificationList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            notificationList: []
        };
    }

    componentDidMount() {

        if (!this.props.emailaddr) {
            alert("User not logged in. Redirecting to login page...");
            this.props.history.push("/");
        } else {
            const requestOptions = {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
                //body: JSON.stringify({ title: 'React POST Request Example' })
            };

            fetch('http://localhost:3001/notification?to=' + this.props.emailaddr + '&_sort=id&_order=desc', requestOptions)
                .then(async response => {

                    const data = await response.json();

                    // check for error response
                    if (response.ok & (data.length > 0)) {
                        this.setState({
                            notificationList: data
                        });
                    } else {
                        alert("No notifications found!");
                    }
                })
                .catch(error => {
                    //this.setState({ errorMessage: error.toString() });
                    console.error('There was an error!', error);
                });
        }

    }

    render() {

        console.log(this.state.notificationList);

        return (

            <div className="NotificationList">
                <div className="header">
                    <a href="/home" className="logo">CompanyLogo</a>
                    <div className="header-right">
                        <Link to="/home" ><IoHomeOutline /></Link>
                        <Link to="/notificationlist" className="active" ><IoNotificationsOutline /><span style={{borderRadius:'50%', fontSize: '15px', backgroundColor: 'red', fontWeight:600, color:'whitesmoke',width:'20px',height:'24px',top:'25px', position:'absolute'}}>{this.state.notificationList.length}</span></Link>
                        <Link to="/logout" onClick={this.logoutHandler} ><IoLogOutOutline /></Link>
                    </div>
                </div>

                <AddNotification />
                <div className="NotListing" style={{ paddingLeft: "20px" }}>
                    <h3>Notification(s) </h3>
                    {this.state.notificationList.length === 0 ? "No notifications" : Object.keys(this.state.notificationList).map((item) =>
                        <div>
                            <details>
                                <summary><b>[{this.state.notificationList[item].date}] Posted by : <i>{this.state.notificationList[item].by}</i></b></summary>
                                <p>{this.state.notificationList[item].message}</p>
                            </details>
                        </div>
                        )
                    }
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        emailaddr: state.emailaddr,
        lastlogin: state.lastlogin
    };
}

export default connect(mapStateToProps)(NotificationList);