import React from 'react'
import './Home.css';
import { IoNotificationsOutline, IoHomeOutline, IoLogOutOutline } from 'react-icons/io5';
import { connect } from 'react-redux';
import { Link } from "react-router-dom";

class Home extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            notificationList: []
        };
    }

    componentDidMount() {

        if (!this.props.emailaddr) {
            alert("User not logged in. Redirecting to login page...");
            this.props.history.push("/");
        } else {

            const requestOptions = {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
                //body: JSON.stringify({ title: 'React POST Request Example' })
            };

            fetch('http://localhost:3001/notification?to=' + this.props.emailaddr + '&_sort=id&_order=desc', requestOptions)
                .then(async response => {

                    const data = await response.json();

                    // check for error response
                    if (response.ok & (data.length > 0)) {
                        this.setState({
                            notificationList: data
                        });
                    } else {
                        console.log("No notifications found!");
                    }
                })
                .catch(error => {
                    //this.setState({ errorMessage: error.toString() });
                    console.error('There was an error!', error);
                });
        }
    }

    render() {

        return (

            <div className="Home">
                <div className="header">
                    <a href="/home" className="logo">CompanyLogo</a>
                    <div className="header-right">
                        <Link to="/home" className="active" ><IoHomeOutline /></Link>
                        <Link to="/notificationlist"><IoNotificationsOutline /><span style={{ borderRadius: '50%', fontSize: '15px', backgroundColor: 'red', fontWeight: 600, color: 'whitesmoke', width: '20px', height: '24px', top: '25px', position: 'absolute' }}>{this.state.notificationList.length}</span></Link>
                        <Link to="/logout" ><IoLogOutOutline /></Link>
                    </div>
                </div>

                <div style={{ paddingLeft: "20px" }}>
                    <h1>Welcome {this.props.emailaddr}</h1>
                    <p>Last login date - <b>{this.props.lastlogin}</b></p>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        emailaddr: state.emailaddr,
        lastlogin: state.lastlogin
    };
}

export default connect(mapStateToProps)(Home);