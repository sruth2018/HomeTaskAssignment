import React from 'react';
import { connect } from 'react-redux';

class Logout extends React.Component {

    constructor(props) {
        super(props);
    }

    componentDidMount() {

        this.props.dispatch({ type: 'UPDATE_USR', emailaddr: "", lastlogin: "" });
        this.props.history.push("/");
    }

    render() {

        return (
            <div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        emailaddr: state.emailaddr,
        lastlogin: state.lastlogin
    };
}

export default connect(mapStateToProps)(Logout);