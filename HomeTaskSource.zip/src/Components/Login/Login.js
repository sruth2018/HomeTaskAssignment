import React from 'react';
import './Login.css';
import { connect } from 'react-redux';

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            useremail: "",
            userpswd: "",
            userObj: {
                emailaddr: "",
                lastlogin: ""
            }
        };

        // This binding is necessary to make `this` work in the callback
        this.usernamechangehandler = this.usernamechangehandler.bind(this);
        this.pswdchangehandler = this.pswdchangehandler.bind(this);
        this.loginUser = this.loginUser.bind(this);
        this.signupUser = this.signupUser.bind(this);
    }

    usernamechangehandler(event) {
        this.setState({ useremail: event.target.value });
    }

    pswdchangehandler(event) {
        this.setState({ userpswd: event.target.value });
    }

    loginUser() {

        // Simple POST request with a JSON body using fetch
        const requestOptions = {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        };

        fetch('http://localhost:3001/users?emailaddr=' + this.state.useremail, requestOptions)
            .then(async response => {

                const data = await response.json();

                // check for error response
                if (!response.ok) {
                    // get error message from body or default to response status
                    const error = (data && data.message) || response.status;
                    return Promise.reject(error);
                } else {
                    console.log(data);
                    if (response.ok & (data.length > 0)) {

                        if (data[0].pswd == this.state.userpswd) {

                            const timestamp = Date.now(); // This would be the timestamp you want to format
                            let currentDateTime = new Intl.DateTimeFormat('en-US', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(timestamp);

                            this.setState({
                                userObj: {
                                    emailaddr: this.state.useremail,
                                    lastlogin: currentDateTime
                                }
                            });
                            let useremail = this.state.userObj.emailaddr;
                            let logindate = this.state.userObj.lastlogin;

                            this.props.dispatch({ type: 'UPDATE_USR', emailaddr: useremail, lastlogin: logindate });
                            this.props.history.push("/home");
                        } else {
                            alert("Incorrect password. Please retry!");
                        }

                    } else {
                        alert("Email not found! Please sign up.");
                    }
                }

            })
            .catch(error => {
                //this.setState({ errorMessage: error.toString() });
                console.error('There was an error!', error);
            });
    }

    signupUser() {

        if (this.state.useremail && this.state.userpswd) {

            const requestOptions = {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
                //body: JSON.stringify({ title: 'React POST Request Example' })
            };

            fetch('http://localhost:3001/users?emailaddr=' + this.state.useremail, requestOptions)
                .then(async response => {

                    const data = await response.json();

                    // check for error response
                    if (response.ok & (data.length > 0)) {
                        alert("Email already registered! Please try log in.");
                    } else {

                        const timestamp = Date.now(); // This would be the timestamp you want to format
                        let currentDateTime = new Intl.DateTimeFormat('en-US', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(timestamp);

                        // POST request using fetch inside useEffect React hook
                        const requestOptions = {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                "emailaddr": this.state.useremail,
                                "pswd": this.state.userpswd,
                                "lastlogin": currentDateTime,
                                "created": currentDateTime
                            })
                        };
                        fetch('http://localhost:3001/users', requestOptions)
                            .then(async response => {

                                const data = await response.json();

                                // check for error response
                                if (response.ok) {
                                    alert("User registered succesfully. Redirecting to Home page");
                                    this.setState({
                                        userObj: {
                                            emailaddr: this.state.useremail,
                                            lastlogin: currentDateTime
                                        }
                                    });
                                    let useremail = this.state.userObj.emailaddr;
                                    let logindate = this.state.userObj.lastlogin;

                                    this.props.dispatch({ type: 'UPDATE_USR', emailaddr: useremail, lastlogin: logindate });
                                    this.props.history.push("/home");
                                } else {
                                    alert("Unable to register email address. Please try again later!!!");
                                }

                            })
                            .catch(error => {
                                //this.setState({ errorMessage: error.toString() });
                                console.error('There was an error!', error);
                            });
                    }

                })
                .catch(error => {
                    //this.setState({ errorMessage: error.toString() });
                    console.error('There was an error!', error);
                });
        } else {
            alert("Username and password is mandatory!!!")
        }

        const requestOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title: 'React POST Request Example' })
        };
        fetch('https://reqres.in/api/posts', requestOptions)
            .then(response => response.json())
            .then(data => this.setState({ postId: data.id }));
    }

    render() {

        const buttonStyle = {
            fontSize: '1.5rem',
            width: '40px',
            height: '40px'
        }

        return (

            <div className="Login">

                <div className="container">
                    <label htmlFor="uname"><b>Email address</b></label>
                    <input type="text" onChange={this.usernamechangehandler} placeholder="Enter email address" name="uname" required />

                    <label htmlFor="psw"><b>Password</b></label>
                    <input type="password" onChange={this.pswdchangehandler} placeholder="Enter Password" name="psw" required />

                    <button type="submit" onClick={this.loginUser}>Login</button>
                    <button type="submit" onClick={this.signupUser}>Sign Up</button>

                </div>

            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        emailaddr: state.emailaddr,
        lastlogin: state.lastlogin
    };
}

export default connect(mapStateToProps)(Login);